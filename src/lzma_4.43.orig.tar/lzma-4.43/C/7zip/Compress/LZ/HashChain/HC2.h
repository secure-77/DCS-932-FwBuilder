// HC2.h

#ifndef __HC2_H
#define __HC2_H

#define BT_NAMESPACE NHC2

#include "HCMain.h"

#undef BT_NAMESPACE

#endif

