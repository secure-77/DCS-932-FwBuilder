// HC3.h

#ifndef __HC3_H
#define __HC3_H

#define BT_NAMESPACE NHC3

#define HASH_ARRAY_2

#include "HCMain.h"

#undef HASH_ARRAY_2
#undef BT_NAMESPACE

#endif

